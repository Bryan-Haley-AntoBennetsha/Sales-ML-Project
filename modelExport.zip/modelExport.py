
import evalml
import woodwork as ww
import pandas as pd

PATH_TO_TRAIN = "train"
PATH_TO_HOLDOUT = "holdout"
TARGET = "f_0"
column_mapping = "columnMapping.json"

# This is the machine learning pipeline you have exported.
# By running this code you will fit the pipeline on the files provided
# and you can then use this pipeline for prediction and model understanding.
from evalml.pipelines.regression_pipeline import RegressionPipeline
from featuretools import load_features

features = load_features("features.json")
pipeline = RegressionPipeline(
    component_graph={
        "DFS Transformer": ["DFS Transformer", "X", "y"],
        "Imputer": ["Imputer", "DFS Transformer.x", "y"],
        "One Hot Encoder": ["One Hot Encoder", "Imputer.x", "y"],
        "RF Regressor Select From Model": [
            "RF Regressor Select From Model",
            "One Hot Encoder.x",
            "y",
        ],
        "Random Forest Regressor": [
            "Random Forest Regressor",
            "RF Regressor Select From Model.x",
            "y",
        ],
    },
    parameters={
        "DFS Transformer": {"features": features},
        "Imputer": {
            "categorical_impute_strategy": "most_frequent",
            "numeric_impute_strategy": "mean",
            "boolean_impute_strategy": "most_frequent",
            "categorical_fill_value": None,
            "numeric_fill_value": None,
            "boolean_fill_value": None,
        },
        "One Hot Encoder": {
            "top_n": 10,
            "features_to_encode": None,
            "categories": None,
            "drop": "if_binary",
            "handle_unknown": "ignore",
            "handle_missing": "error",
        },
        "RF Regressor Select From Model": {
            "number_features": None,
            "n_estimators": 10,
            "max_depth": None,
            "percent_features": 0.5,
            "threshold": "median",
            "n_jobs": -1,
        },
        "Random Forest Regressor": {"n_estimators": 100, "max_depth": 6, "n_jobs": -1},
    },
    random_seed=0,
)


print(pipeline.name)
print(pipeline.parameters)
pipeline.describe()

df = ww.deserialize.from_disk(PATH_TO_TRAIN)
y_train = df.ww[TARGET]
X_train = df.ww.drop(TARGET)
pipeline.fit(X_train, y_train)

# You can now generate predictions as well as run model understanding.
df = ww.deserialize.from_disk(PATH_TO_HOLDOUT)
y_holdout = df.ww[TARGET]
X_holdout = df.ww.drop(TARGET)

pipeline.predict(X_holdout)

# Note: if you have a column mapping, to predict on new data you have on hand
# Map the column names and run prediction
# X_test = X_test.rename(column_mapping, axis=1)
# pipeline.predict(X_test)

# For more info please check out:
# https://evalml.alteryx.com/en/stable/user_guide/automl.html
